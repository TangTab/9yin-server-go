-- 0022_add_role_attire_blends_20261118.sql
-- 梳妆阁图纸系统（attire_blend.go，server2 方案移植）：新表
-- role_attire_blends（图纸→装备件绑定快照，key=物品视图 UniqueID 口径、
-- value=图纸 ConfigID）。结构对齐 0006 role_skins 的快照表方言
--（role_id PK + version + updated_at，FK roles ON DELETE CASCADE）。

CREATE TABLE IF NOT EXISTS `role_attire_blends` (
  `role_id` bigint unsigned NOT NULL,
  `blends` json NOT NULL,
  `version` bigint unsigned NOT NULL DEFAULT '1',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`),
  CONSTRAINT `fk_attire_blends_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
